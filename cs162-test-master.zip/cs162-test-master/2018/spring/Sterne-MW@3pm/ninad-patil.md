# Ninad Patil

## Student at Minerva Schools at KGI

#### Likes Indian Food

**Music: House, neo-soul and techno**

*thoughts about italian food: none*

* I 
* Will
* Show
    * You 
    * The 
    * Way
    
# :D