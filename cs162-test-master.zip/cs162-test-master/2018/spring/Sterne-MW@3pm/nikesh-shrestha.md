# This is Nikesh Shrestha

1. Things I did when I was a kid
    * Eat
    * Sleep
    * Sleep
    * Sleep
    * Laugh
1. **What I do now?**
    * _Eat_
    * _Sleep_


But as our daily quote in the ALF by **_ALF God_**

> You have two classes today and nothing else
