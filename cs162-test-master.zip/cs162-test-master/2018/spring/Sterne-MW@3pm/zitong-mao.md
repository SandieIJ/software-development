# Zitong Mao

**CS Student at [Minerva Schools](https://www.minerva.kgi.edu/)**

About Myself:

1. An Enthusiastic Gamer:
* Hearthstone Ex-Pro, Ranked Top 100 in China ~~, Stopped playing after joining Minerva~~
* In possession of:
- [x] 1000+ games
- [ ] 100-999 games
- [ ] 10-99 games
- [ ] 0-9 games

2. A Credit Card ~~Churner~~ Lover:
* Have 20+ US credit cards with ~500k miles ~~churned~~ earned from ~~evil capitalists~~ banks.
