#Hey There, My name is Brian Wahome from Kenya, I am an aspiring developer, an artist and science enthusiast. Some of my favorite languages are as follows:
# Brian WAhome

## A science and technology enthusiast, Kenyan.
#### Likes, football, family

##Languages I love
* C 
* C++
* Java