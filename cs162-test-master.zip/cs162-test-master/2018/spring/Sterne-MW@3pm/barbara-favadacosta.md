**Barbara Fava da Costa**  <br/>
Brazilian kiddo struggling her way through what is called a _degree_  <br/>
Has several interests in life: <br/>
* Dance
* Survive
* Get 8 hours of sleep
* Ice cream
* ???
* Profit
