*Hi*, I'm **Long**. You can find my GitHub profile [Here](https://github.com/LongntLe)

# This is a header
## Another smaller header
#### ~~How much smaller could we get?~~

# I creates **lists** in my freetime!

Just like _this_:
1. First item
2. Another item
  * Sub item
  * Another subitem
3. ~~Last item~~

## Sometimes, tables are cool too:
This is | A Table
:------------: | -------------:
Center-aligned| Right Aligned

## Also, here is an awesome inspiring quote:
> An awesome inspiring quote. 

