# Biography

## January 15, 2018

**Attribute** | **Value**
--------- | -------
First Name | *Nifesh*
Last Name | *Chakubaji*
Permanent Residence | [Kathmandu, Nepal](https://en.wikipedia.org/wiki/Kathmandu)
Current Residence | [Hyderabad, India](https://en.wikipedia.org/wiki/Hyderabad)
Profession | Student
Passion | Basketball, Music



