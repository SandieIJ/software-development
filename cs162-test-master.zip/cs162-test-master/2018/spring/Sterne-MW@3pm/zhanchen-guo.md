# Zhanchen Guo Bibliography

[A young boy](https://github.com/markguo40) that was born in a island of China.

## Hobby:

* Professional chiller
* coding
    * I am *lazy* so only code when necessary

## Favorite Quote:

> Never memorize something that you can look up
    ― Albert Einstein

**Thanks for reading**

## Sugar:

A [tool](https://stackedit.io/app) for checking your readme file

