# markdown is scary
## really, been coding for a while, never understood it

it's not as easy as:
  '''python
  if 1==0:
  	print "end of days"
  else:
  	print "reality is ok"
  '''
||||||| merged common ancestors
'''python
if 1==0:
	print "end of days"
else:
	print "reality is ok"
'''

I am a _lewis carroll_ fan, and __especially__ of his nonsense:

> "The time has come," the Walrus said,
> "To talk of many things:
> Of shoes--and ships--and sealing-wax--
> Of cabbages--and kings--
> And why the sea is boiling hot--
> And whether pigs have wings."

- I like to make lists
  - they're helpful for organizing things
  - and remaining productive
  - even for communicating
- Being right is often not good for you


##### TODO:
- [X] write this markdown
- [ ] get good grades in Sterne's class :shipit:
- [ ] help the ~~bad~~ good guys