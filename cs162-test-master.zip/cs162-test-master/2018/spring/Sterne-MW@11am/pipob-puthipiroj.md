Hi! I'm Jacob. I'm an NS and AH major. I **love** books, especially *Eat, Pray, Love* and *Seventeen Magazine*. Some of my hobbies include:
1. Watching great movies like Twilight: Breaking Down
2. Listening to the biebs 
