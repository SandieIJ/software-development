Hi, my name is Namrata. I am 22 and from Mumbai. Currently studying at Minerva in Hyderabad. I **love** languages. 
