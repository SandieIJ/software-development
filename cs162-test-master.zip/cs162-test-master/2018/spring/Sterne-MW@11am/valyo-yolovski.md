# Valyo Yolovski

## About

 - Concentrations: **Data Scientist and Back-End Software Engineer**

 - Education: BS Data Science and Statistics, [Minerva Schools](https://minerva.kgi.edu/)

