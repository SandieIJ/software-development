### Ben Imadali
__As a young man Benjamin Yannis Imadali...__
1. Completed the entire set of Pokémon games on the Nintendo GameBoy Color, Advance, and SP in under 30 minutes (*exact time was 27 minutes 32 seconds*)
1. Learned how to play flight of the bumblebee on an alto saxophone before he knew how to read music
1. Made [**super dope** montages of people playing video games](https://www.youtube.com/watch?v=ip9AE_KgLdc)
1. Programmed his first application that was a more sophisticated implementation of the Ethereum network in only one line of code which can be seen below:
`code.ask(bloobity do, how are you?)`
___
