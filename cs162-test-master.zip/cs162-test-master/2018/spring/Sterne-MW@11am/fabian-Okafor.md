##### biography

# Name: Fabian Okafor Chibuike

**Country of origin: Nigeria**

Things I love:
1. Food
2. Friends
3. Sleep

~~Age: That's for me to know and for you to find out~~ :smile:

Things to do today
- [x] Sleep
- [ ] Take class
- [ ] Eat
- [ ] Kill mosquitoes
- [ ] Sleep

Favourite quote: In the words of my fore fathers:
> If life gives you pepper, make pepper soup.

