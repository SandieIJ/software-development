# My name's Seth.
#### Howzit You Well?
###### Ya no howzit.

----
## I'm from Cape Town.

...as long as you're willing to accept that Somerset West is a part of Cape Town (which it is, see the second sentence on [this highly accurate and oftentimes-cited website](https://en.wikipedia.org/wiki/Somerset_West))

Check out some sweet pics of my city [here](http://www.travelstart.co.za/blog/50-photos-of-cape-town-that-will-make-you-want-to-live-in-the-mother-city/).

And, you know, it wasn't easy growing up at the South West tip of Africa. The endless picturesque mountain ranges and white sandy beaches alongside bustling rustic markets and exceptionally delicious food from every corner of the Earth sometimes made me yearn for the ordinary. It's as if things were just too good, all the time. Like, it gets boring. Alas, I was stuck here.

----
## Here's a short summary of my life
1. Born in Cape Town as mentioned
2. Went to high school
3. Gap year'd for 2 years, living and working in the city. Travelled around America trying to build THE MOST EPIC SUMMER ABROAD [APPLY NOW LIMITED SPOTS!!!](http://ixperience.co.za)
5. Someone sent me Minerva's website
6. Was sold on their marketing
7. Came to Minerva
8. ?
9. Am at Minerva
10. *This was really just to prove I can use lists in markdown sorry for wasting your time*

----
## Pearls of Wisdom from Seth

>"Only dead fish go with the flow. Don't be a dead fish."

## How do I remove this pathetic page?
Easy. Use the command line to navigate to my section's folder (MW @ 11am) and run:

    git rm seth-fuchs.md
    git add --all
    git commit -am "somerset west is not in cape town"
    git push -u origin your-branch-name
