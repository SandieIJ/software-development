## Hi, I'm Ning.
I'm learning how to use git and be a good programmer. 

Before I started Minerva and bid goodbye to spare time, I used to collect quotes from books and post them on my [book blog.](https://joyoftedium.wordpress.com/)

Among some of my favorites are:

> “Human speech is like a cracked kettle on which we tap crude rhythms for bears to dance to, while we long to make music that will melt the stars.” 
> - Gustave Flaubert

> “You can be merry with the king, you can share a joke with him. But as Thomas More used to say, it’s like sporting with a tamed lion.  You can tousle its mane and pull its ears, but all the time you’re thinking, those claws, those claws, those claws.”
> - Hilary Mantel

> “Trust but check. Check on those we trust.” 
> - Tom Rob Smith

> "All that is gold does not glitter, Not all those who wander are lost; The old that is strong does not wither, Deep roots are not reached by the frost. From the ashes a fire shall be woken, A light from the shadows shall spring; Renewed shall be the blade that was broken, The crownless again shall be king."
> - J. R. R. Tolkien

### Some of my favorite books:

1. 1984
2. Watership Down
3. Brave New World
4. Flowers for Algernon
5. Of Mice and Men

*etc, etc.*

My favorite genres are **Science-fiction** and **Mystery**, and I'm always open to recommendations! 

Unfortunately I haven't had much time to read lately. :pensive:

But it's okay, I just try to squeeze in some short novellas here and there.

