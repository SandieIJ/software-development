#A biography- maybe
## Patrick Mutuku

** Quick facts **
* Age: 200years
* Height: 8ft 0"
* Weight: 120lb

* Self description *
I am not a programmer - but I do try write code though. 

** Favorite site**
> Stack Overflow

####Darkest secret
~~None~~
