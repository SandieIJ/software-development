##Bibliography 
1. *I* am an **arts student**. 
1. Can someone remind me how I end up here?
1. Reviews & Rating:

Prof. W

> A great writer!
> A surprise delight!

Roommate

> Don't believe him,
> He's only decent at best