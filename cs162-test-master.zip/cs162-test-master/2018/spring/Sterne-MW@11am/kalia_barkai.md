﻿# Kalia Barkai : a short story

## Chapter 1: 
Kalia grew up and was born in Cape Town, South Africa (*People who believe that Cape Town includes Somerset West are confused.*)

![enter image description here](https://scontent.fhyd2-1.fna.fbcdn.net/v/t1.0-9/200218_4650927918_5996_n.jpg?oh=a541503cde24806ebe8be00272806955&oe=5AE7C73B)

## Chapter 2:

Kalia has two siblings:
* Ittai Barkai
* Lenoy Barkai

## Chapter 3:

Kalia is currently reading **1984** by George Orwell:

> “Who controls the past controls the future. Who controls the present controls the past.” - **1984, George Orwell**

## Chapter 4:

Kalia is planning on completing a data science concentration, this involves code and math:

    def kalia_at_minerva():
	    return degree

$$c^{2} = a^{2} + b^{2} $$

## Chapter 5:

### Chapter 5.1

#### Chapter 5.2

|Things|Kalia's likes/dislikes  |
|--|--|
|Giraffes | Y |
|Mustard|N|
|Prawn Springrolls|Y|
|Mayonnaise|N|
|Art|Y|
|Cape Town|Y|
|Horrors|N|


----------


### *To be continued...*

